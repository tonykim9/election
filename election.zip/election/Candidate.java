package harderharder;

import java.util.Random;



public class Candidate implements Comparable<Candidate>{
public String name;
public int numVotes;
public Vote[] vote;


public Candidate(String name, int maxVotes){
	this.name=name;
	vote=new Vote[maxVotes];
}
/*
public int compareTo(Candidate c){
return Integer.compare(this.numVotes, c.numVotes);	
}*/

public int compareTo(Candidate other) throws ClassCastException,NullPointerException
{
	
	if (other==null) throw new NullPointerException();
	if (!other.getClass().equals(getClass())) 
		System.err.println("can't compare");
	
	Candidate otherCandidate = (Candidate) other;
	
	if (otherCandidate.numVotes<numVotes) return -1;
	else if (otherCandidate.numVotes==numVotes) return 0;
	else return 1;
}



public String toString(){
	String result="";
	result+="---------------Candidate---------------\r\n";
	result+="Name: "+this.name+"\r\n";
	result+="Votes: "+this.numVotes+"\r\n";
	result+="\r\n";
	result+="=======================================\r\n";
	return result;
}


/*public String toString(){
	return "-----------------Candidate--------------------\n"+"Name:"+name+"\n"+"Votes:"+numVotes+"\n\n===================";
}*/

private class Vote{
	public int regionNum;
	
	public Vote(int regionNum){
		this.regionNum=regionNum;
	}
	
	
}


public synchronized void addVote(int regionNum) {
	synchronized(this){
		Vote v1=new Vote(regionNum);
		vote[numVotes++]=v1;
	}
	
}
}



