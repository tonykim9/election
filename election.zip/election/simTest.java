package harderharder;

public class simTest {
	
	private static final String INPUTFILE="C:/Users/tonykim9/Desktop/inputfile.txt";
	private static final String OUTPUTFILE="C:/Users/tonykim9/Desktop/outputfile.txt";

	public static void main(String[] args) {
		
		ElectionSim eSim=new ElectionSim(INPUTFILE, OUTPUTFILE);
		eSim.runSimulation();
		// TODO Auto-generated method stub

	}

}




