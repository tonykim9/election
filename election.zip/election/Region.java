package harderharder;

import java.util.Random;

public class Region extends Thread{
public String name;
public int regionNum;
public int population;
public Candidate[] candidates;

public Region(String name, int regionNum, int population, Candidate[] candidates){
	this.name=name;
	this.regionNum=regionNum;
	this.population=population;
	this.candidates=candidates;
}
public void generateVotes(){
	Random random=new Random();
	int a=random.nextInt(8);
	candidates[a].addVote(regionNum);
}

public void run(){
	for(int i=0; i<population;i++){
	generateVotes();
	}
}


}
