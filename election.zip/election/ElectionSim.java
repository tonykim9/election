package harderharder;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner; 
import java.util.Arrays;



public class ElectionSim {
public String outputFile;
public int population;
public Candidate[] candidates;
public Region[] regions;

public ElectionSim(String inputFile, String outputFile){
this.outputFile=outputFile;

try{
	  Scanner scan = new Scanner( new FileInputStream(inputFile));
	  scan.next();
	  population=scan.nextInt();
	  
	  scan.next();
	  int candidatesNum=scan.nextInt();
	  candidates=new Candidate[candidatesNum];
	  for(int i=0;i<candidates.length;i++){
		  String name=scan.next();
		  candidates[i]=new Candidate(name, population);
	  }
	  
	  scan.next();
	  int regionsNum=scan.nextInt();
	  regions=new Region[regionsNum];
	  for(int i=0;i<regions.length;i++){
		  String name=scan.next();
		  int num=scan.nextInt();
		  int pop=scan.nextInt();
		  regions[i]=new Region(name, num, pop, candidates);
	  }
} catch(FileNotFoundException e){
	e.printStackTrace();
}
}
 
public void saveData(){
	//sort
	Arrays.sort(candidates);
	try{
	    PrintWriter output = new PrintWriter(new FileOutputStream(outputFile));
    for(int i=0; i<candidates.length; i++) {
    	output.println(candidates[i].toString());
    }
        output.flush();
	}catch (FileNotFoundException e){
		e.printStackTrace();
	}
}
       
public void runSimulation(){
for(int i=0; i<regions.length;i++){
	regions[i].start();
	try{
		regions[i].join();
	}catch (InterruptedException e){
		e.printStackTrace();
	}
}
saveData();
}
}
